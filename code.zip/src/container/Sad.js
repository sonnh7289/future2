function Sad() {
    return <div>hello from sad</div>;
}

export default Sad;
